f = float(input('°F = '))
print ("{:.2f} °F = {:.2f} °C" .format(f, ((f - 32) * 5) / 9))