import math
r = float(input("Raio (em cm): "))
print ("Volume = {:.2f} cm³\nÁrea = {:.2f} cm²" .format((4 / 3) * math.pi * r ** 3, 4 * math.pi * r ** 2))