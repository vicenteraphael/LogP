import math
r = float(input("Raio (em cm): "))
print ("\nÁrea = {:.2f} cm²\nComprimento = {:.2f} cm" .format(math.pi * r ** 2, 2 * math.pi * r))