a = float(input("A = "))
b = float(input("B = "))
c = a
a = b
b = c
print ("A = {:.2f}\nB = {:.2f}" .format(a, b))