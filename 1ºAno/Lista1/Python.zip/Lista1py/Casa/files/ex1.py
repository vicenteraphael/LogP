r = float(input("R$ = "))
print ("R$ {:.2f} = US$ {:.2f}" .format(r, r / 2.4))