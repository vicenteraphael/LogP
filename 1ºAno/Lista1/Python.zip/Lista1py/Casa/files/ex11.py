a = float(input("A = "))
b = float(input("B = "))
a, b = b, a
print ("A = {:.2f}\nB = {:.2f}" .format(a, b))