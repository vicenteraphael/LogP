d = float(input("US$ = "))
print ("US$ {:.2f} = R$ {:.2f}" .format(d, d * 2.4))