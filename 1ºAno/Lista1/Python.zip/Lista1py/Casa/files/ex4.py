print ("Entre com dois lados adjacentes do retângulo (base e altura): ")
a = float(input("Base (em cm) = "))
b = float(input("Altura (em cm) = "))
print ("\nÁrea = {:.2f} cm²\nPerímetro = {:.2f} cm" .format(a * b, a * 2 + b * 2))