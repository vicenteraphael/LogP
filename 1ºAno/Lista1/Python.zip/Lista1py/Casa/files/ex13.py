seg = float(input('Segundos (t) = '))
print ("Metros (s) = {:.2f}" .format(2 + 3 * seg + 0.5 * 10 * seg ** 2))