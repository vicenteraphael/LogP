#include <stdio.h>

int main() {

    double x;
    printf ("X = ");
    scanf ("%lf", &x);
    printf ("X² = %.2lf\n", x * x);

    return 0;
}